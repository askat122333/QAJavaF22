package part2.artCompany;

public class Client {
}
