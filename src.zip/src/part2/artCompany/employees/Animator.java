package part2.artCompany.employees;

import part2.company.Employee;

public class Animator extends Employee {
}
