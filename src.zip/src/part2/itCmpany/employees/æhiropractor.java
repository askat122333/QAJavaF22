package part2.itCmpany.employees;

import part2.company.Employee;

public class Сhiropractor extends Employee {
}
