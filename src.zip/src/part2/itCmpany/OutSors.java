package part2.itCmpany;

public class OutSors {
}
