package part1;

import java.util.Scanner;

public class MainCompany {
    public static void start(Company company) {
        Scanner in = new Scanner(System.in);

        while (true) {
            System.out.println("Меню для работы с компанией: ");
            System.out.println("1) Вывод информации о компании");
            System.out.println("2) Вывод списока сотрудников компании");
            System.out.println("3) Вывод общих расходов на зарплаты сотрудников");
            System.out.println("4) Добавление сотрудника в компанию");
            System.out.println("5) Удаление сотрудника из компании");
            System.out.println("6) Поменять руководителя компании");
            System.out.println("7) Меню для работы с сотрудниками");
            System.out.println("0) Выход из главного меню");
            int command = in.nextInt();
            if (command == 1) {
//Реализуйте вывод информации об этой компании (кроме списка сотрудников)
                System.out.println("Информация о компании - ");
                System.out.println(  company.toString());
            } else if (command == 2) {
//Реализуйте вывод списка сотрудников этой компании
                System.out.println("Список сотрудников - ");
                company.showEmployees();
            } else if (command == 3) {
//Реализуйте подсчет всех зароботных плат сотрудников
                System.out.println("Затараты на зароботную плату - ");
                company.getOverallSalary();
            } else if (command == 4) {
//Реализуйте добавление сотрудника в компанию
                /*  Employee employee1 = new Employee("ben",130000,"Директор");
                Employee employee2 = new Employee("Den",90000,"JavaDev");
                Employee employee3 = new Employee("Gven",40000,"Стажер");
                Employee employee4 = new Employee("Sven",40000,"Стажер");
                Employee [] employees = new Employee[10];
                employees[0] = employee1;
                employees[1] = employee2;
                employees[2] = employee3;*/
                System.out.println("Должность -");
                String jobTitle = in.next();
                System.out.println("Имя -");
                String name = in.next();
                System.out.println("Зарплата -");
                int salary = in.nextInt();
                company.addEmployee(new Employee(name,salary,jobTitle));

            } else if (command == 5) {
//Реализуйте удаление сотрудника из компании
                System.out.println("Кого уволить - ");
                String name = in.next();
                company.deleteEmployee(name);
            } else if (command == 6) {
//Реализуйте смену руководителя компании
                System.out.println("Кого сделать руководителем? :");
                String employeeName = in.next();
                if (employeeName != null){
                   company.changeSupervisor(employeeName);
                }else {
                    System.out.println("Такого человека нету");
                }

            } else if (command == 7) {
                //Реализуйте поиск сотрудника по имени
//P.S. метод getEmployeeByName() пустой нужно его заполнить
                System.out.println("Имя сотрудника :");
                String employeeNames = in.next();
                Employee foundedEmployee = company.getEmployeeByName(employeeNames);
                if (foundedEmployee != null){
                    MainEmployee.start(foundedEmployee);
                }else {
                    System.out.println("Такого человека нету");
                }


            } else if (command == 0) {
                break;
            } else {
                System.out.println("Ошибка! Введите пункт из меню");
            }
        }
    }
}